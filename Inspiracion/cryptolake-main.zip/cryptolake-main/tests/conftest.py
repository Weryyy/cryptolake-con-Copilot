"""Pytest fixtures for CryptoLake."""
